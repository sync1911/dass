function init() {
  document.getElementById('send-button').addEventListener('click', (event) => {
    event.preventDefault();
    submitMessage();
  });
}

async function submitMessage() {
  const messageInput = document.getElementById('user-input');
  const userMessage = messageInput.value.trim();

  if (userMessage.length === 0) {
    return;
  }

  addMessage(userMessage, 'user');
  messageInput.value = '';

  const aiResponse = await sendChatRequest(userMessage);
  addMessage(aiResponse, 'ai');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function addMessage(message, sender) {
  const messageContainer = document.getElementById('message-container');
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', sender);
  messageElement.textContent = message;
  messageContainer.appendChild(messageElement);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function sendChatRequest(userInput) {
  return fetch('http://127.0.0.1:8000/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `user_input=${encodeURIComponent(userInput)}`,
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }
      return response.json();
    })
    .then((data) => data.response)
    .catch((error) => {
      console.error('Error fetching chat response:', error);
      return 'An error occurred while fetching the chat response.';
    });
}