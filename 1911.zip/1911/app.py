
from flask import Flask, render_template, request, jsonify
import openai
import os

app = Flask(__name__)
openai.api_key = os.getenv("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")

@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    response = generate_chat_response(user_input)
    return jsonify(response=response)

def generate_chat_response(user_input):
    prompt = f"User: {user_input}\nAI:"
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        max_tokens=150,
        n=1,
        stop=None,
        temperature=0.5,
    )

    message = response.choices[0].text.strip()
    return message

if __name__ == '__main__':
    app.run(debug=True)
